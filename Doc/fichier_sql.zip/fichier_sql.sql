DROP TABLE IF EXISTS manga;

CREATE TABLE manga (
    id_manga INT AUTO_INCREMENT,
    titre  VARCHAR(100) PRIMARY KEY,
    auteur VARCHAR(100),
    annee_publication INT
    stock INT
);

ALTER TABLE manga ADD CONSTRAINT manga_pk PRIMARY KEY ( id_manga );

INSERT INTO manga (id_manga, titre, auteur, annee_publication, stock) VALUES
('One Piece', 'Eiichiro Oda', 1997, 20),
('Naruto', 'Masashi Kishimoto', 1999, 20),
('Blue Lock', 'Muneyuki Kaneshiro', 2018, 20);




DROP TABLE IF EXISTS carte;

CREATE TABLE carte (
    id_carte INT AUTO_INCREMENT,
    nom VARCHAR(100),
    anime VARCHAR(100) PRIMARY KEY,
    edition VARCHAR(100),
    rarete VARCHAR(100)
    stock INT
);

ALTER TABLE carte ADD CONSTRAINT carte_pk PRIMARY KEY ( id_carte );

INSERT INTO carte (nom, anime, edition, rarete, stock) VALUES
('Trafalgar Law 047', 'One Piece', 'Bandai', 'Parallel', 20),
('Jiraiya Sage Mode', 'Naruto', 'Bandai', 'Super Rare', 20),
('Charizard', 'Pokemon', 'Wizards of the Coas', 'Rare', 20);




DROP TABLE IF EXISTS jeux_video;

CREATE TABLE jeux_video (
    id_jeux_video INT AUTO_INCREMENT,
    titre VARCHAR(100),
    anime VARCHAR(100) PRIMARY KEY,
    developpeur VARCHAR(100),
    plateforme VARCHAR(100)
    stock INT
);

ALTER TABLE jeux_video ADD CONSTRAINT jeux_video_pk PRIMARY KEY ( id_jeux_video );

INSERT INTO jeux_video (titre, anime, developpeur, plateforme, stock) VALUES
('One Piece Odyssey', 'One Piece', 'ILCA, Inc.', 'PC', 20),
('Naruto Shippuden: Ultimate Ninja Storm 3', 'Naruto', '	CyberConnect2', 'PlayStation 3', 20),
('Pokemon FireRed', 'Pokemon', 'Game Freak', 'Game Boy Advance', 20);


DROP TABLE IF EXISTS figurine;

CREATE TABLE figurine (
    id_figurine INT AUTO_INCREMENT,
    nom VARCHAR(100),
    anime VARCHAR(100) PRIMARY KEY,
    prix DECIMAL(5,2),
    fabricant VARCHAR(100)
    stock INT
);

ALTER TABLE figurine ADD CONSTRAINT figurine_pk PRIMARY KEY ( id_figurine );

INSERT INTO figurine (nom, anime, prix, fabricant, stock) VALUES
('Grand Ship Collection 01 - Thousand Sunny', 'One Piece', 26.99, 'Bandai', 20),
('Precious G.E.M Uchiha Itachi Susanoo Ver.', 'Naruto', 899.99, 'MegaHouse', 20),
('Nagi Seishiro', 'Blue Lock', 79.99, 'Nendoroid', 20);


CREATE TABLE purchase (
    id_purchase INT AUTO_INCREMENT,
    id_client INT,
    cout DECIMAL(5,2),
    purchase_id_manga INT,
    purchase_id_carte INT,
    purchase_id_jeux_video INT,
    purchase_id_figurine INT
);

INSERT INTO purchase (id_client, cout, purchase_id_manga, purchase_id_carte, purchase_id_jeux_video, purchase_id_figurine) VALUES
(1, 26.99, 1, NULL, NULL, NULL),
(2, 899.99, NULL, NULL, NULL, 2),
(3, 79.99, NULL, NULL, NULL, 3)

ALTER TABLE purchase ADD CONSTRAINT purchase_pk PRIMARY KEY ( id_purchase );

ALTER TABLE purchase
    ADD CONSTRAINT purchase_client_fk FOREIGN KEY ( id_client )
        REFERENCES client ( id_client );

ALTER TABLE purchase
    ADD CONSTRAINT purchase_manga_fk FOREIGN KEY ( purchase_id_manga )
        REFERENCES manga ( id_manga );

ALTER TABLE purchase
    ADD CONSTRAINT purchase_carte_fk FOREIGN KEY ( purchase_id_carte )
        REFERENCES carte ( id_carte );

ALTER TABLE purchase    
    ADD CONSTRAINT purchase_jeux_video_fk FOREIGN KEY ( purchase_id_jeux_video )
        REFERENCES jeux_video ( id_jeux_video );

ALTER TABLE purchase    
    ADD CONSTRAINT purchase_figurine_fk FOREIGN KEY ( purchase_id_figurine )
        REFERENCES figurine ( id_figurine );

INSERT INTO purchase (id_client, cout, purchase_id_manga, purchase_id_carte, purchase_id_jeux_video, purchase_id_figurine) VALUES


-- Ceci va creer un URI sous le URL qui pourra etre utilise pour y activer les tables en mode REST
BEGIN
  ORDS.enable_schema(
    p_enabled             => TRUE,
    p_schema              => 'RESTSCOTT',
    p_url_mapping_type    => 'BASE_PATH',
    p_url_mapping_pattern => 'hr2',
    p_auto_rest_auth      => FALSE
  );
    
  COMMIT;
END;
/

-- Activation de la table manga pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'MANGA',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'MANGA'
  );
    
  COMMIT;
END;
/

-- Activation de la table carte pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'CARTE',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'CARTE'
  );
    
  COMMIT;
END;
/

-- Activation de la table jeux_video pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'JEUX_VIDEO',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'JEUX_VIDEO'
  );
    
  COMMIT;
END;
/

-- Activation de la figurine pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'FIGURINE',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'FIGURINE'
  );
    
  COMMIT;
END;
/

-- Activation de la table purchase pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'PURCHASE',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'PURCHASE'
  );
    
  COMMIT;
END;
/

-- Confirmation de l'activation du schema
SELECT *
FROM user_ords_schemas;

-- Confirmation de l'activation des tables pour REST
SELECT *
FROM   user_ords_enabled_objects;

